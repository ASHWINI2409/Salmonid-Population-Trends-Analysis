import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Set plot styles
sns.set(style="whitegrid")
plt.rcParams["figure.figsize"] = (12, 6)

# Load the dataset
file_path = "C:\\Users\\ashwi\\Downloads\\WDFW-Salmonid_Population_Indicators__SPI__Escapement_and_pHOS_20250410.csv"
df = pd.read_csv(file_path)

print("\n Dataset Overview:")
print(df)

print("\n Head of the dataset:")
print(df.head())

print("\n Tail of the dataset:")
print(df.tail())

print("\n Summary Statistics:")
print(df.describe())

print("\n Information:")
print(df.info())

print("\n Column Names:")
print(df.columns)

print("\n Shape of Dataset:")
print(df.shape)

# Clean column names
df.columns = df.columns.str.strip()


# Objective 1: Data Cleaning & Histogram

df['Abundance Quantity'] = df['Abundance Quantity'].str.replace(',', '', regex=False)
df['Abundance Quantity'] = pd.to_numeric(df['Abundance Quantity'], errors='coerce')
abundance_cleaned = df['Abundance Quantity'].dropna()

plt.figure(figsize=(12, 6))
sns.histplot(abundance_cleaned, bins=50, color='steelblue', edgecolor='black')
plt.title('Distribution of Abundance Quantity (Histogram Only)', fontsize=14)
plt.xlabel('Abundance Quantity')
plt.ylabel('Frequency')
plt.tight_layout()


# Objective 2: Species-wise Abundance Over Time
species_year_df = (
    df.dropna(subset=['Year', 'Abundance Quantity'])
    .groupby(['Species', 'Year'])['Abundance Quantity']
    .mean()
    .reset_index()
)

plt.figure(figsize=(14, 6))
sns.lineplot(data=species_year_df, x='Year', y='Abundance Quantity', hue='Species', marker='o')
plt.title('Average Escapement Abundance per Species Over Time')
plt.xticks(rotation=45)
plt.tight_layout()


# Objective 3: Escapement Methodology Comparison

method_df = df[['Escapement Methodology', 'Abundance Quantity']].dropna()
method_df['Abundance Quantity'] = pd.to_numeric(method_df['Abundance Quantity'], errors='coerce')

plt.figure(figsize=(14, 6))
sns.violinplot(data=method_df, x='Escapement Methodology', y='Abundance Quantity', hue='Escapement Methodology', legend=False, inner='box', palette='muted')
plt.xticks(rotation=90)
plt.title('Abundance by Escapement Methodology (Violin Plot)')
plt.tight_layout()


# Objective 4: Production Type Distribution Analysis

prod_df = df[['Production Type', 'Abundance Quantity']].dropna()
prod_summary = prod_df.groupby('Production Type')['Abundance Quantity'].sum().sort_values(ascending=False)

plt.figure(figsize=(10, 6))
prod_summary.plot(kind='barh', color='skyblue')
plt.title('Total Abundance by Production Type')
plt.xlabel('Total Abundance')
plt.ylabel('Production Type')
plt.tight_layout()


# Objective 5: Correlation Between Calculation & Methodology

cross_tab = pd.crosstab(df['Calculation Type'], df['Escapement Methodology'])

plt.figure(figsize=(14, 8))
sns.heatmap(cross_tab, annot=True, fmt='d', cmap='YlGnBu')
plt.title('Calculation Type vs Escapement Methodology')
plt.tight_layout()


# Objective 6: Donut Chart of Species Distribution

species_counts = df['Species'].value_counts()
plt.figure(figsize=(8, 8))
plt.pie(species_counts, labels=species_counts.index, autopct='%1.1f%%', startangle=140, wedgeprops={'width': 0.4})
plt.title('Species Distribution in Dataset (Donut Chart)')
plt.tight_layout()


plt.show()
